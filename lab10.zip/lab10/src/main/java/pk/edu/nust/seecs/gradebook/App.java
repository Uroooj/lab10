package pk.edu.nust.seecs.gradebook;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.dao.CourseDao;
import pk.edu.nust.seecs.gradebook.entity.Course;
import pk.edu.nust.seecs.gradebook.dao.GradeDao;
import pk.edu.nust.seecs.gradebook.entity.Grade;
import pk.edu.nust.seecs.gradebook.dao.StudentDao;
import pk.edu.nust.seecs.gradebook.entity.Student;
import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Teacher;
/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {

    public static void main(String[] args) {
        CloDao clodao = new CloDao();
        ContentDao contentdao = new ContentDao();
        StudentDao studentdao = new StudentDao();
        TeacherDao teacherdao = new TeacherDao();
        // Add new clo
        Clo clo = new Clo();
        clo.setName("CLO 1");
        clo.setDescription("Design efficient solutions for algorithmic problems");
        clo.setPlo("2");
        clodao.addClo(clo);

        clodao.updateClo(clo);     

        // Delete an existing clo
        //dao.deleteClo(1);

        // Get all clos
        for (Clo iter : clodao.getAllClos()) {
            System.out.println(iter);
        }

        // Get clo by id
        System.out.println(clodao.getCloById(1));
        
        Student student = new Student();
        student.setName("Urooj");
        studentdao.addStudent(student);
        
        studentdao.updateStudent(student);
        
        Teacher teacher = new Teacher();
        student.setName("Hussain");
        teacherdao.addTeacher(teacher);
        
        teacherdao.updateTeacher(teacher);
        
        
        //Content content = new Content();
        //content.setTitle("This is a title");
        //content.setDescription("Description");
        //content.setClo((List<Clo>) clo);
        //content.setStarttime("12");
        //content.setEndtime(12);
        
        
        
        
          

        
    }

}